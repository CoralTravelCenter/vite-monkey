import markup from '../markup.html?raw';
import popupMarkup from '../popup.html?raw';

import {HEADER_SELECTOR, POPUP_SELECTOR, POPUP_TRIGGER_SELECTOR,} from './constants.js';

import {sendCapsulaClickMetric, sendLearnMoreMetric, sendPopupOpenMetric,} from './metrics.js';

function bindShadowCloseMetric(popup) {
  const shadowRoot = popup?.shadowRoot;

  if (!shadowRoot) {
    console.warn(
      '[Elite] Shadow DOM popup недоступен'
    );

    return;
  }

  const closeSelector = [
    '[part~="close-button"]',
    '[part~="popup-close"]',
    '[part~="close"]',
    'button[aria-label="Закрыть"]',
    'button[aria-label="Close"]',
    '[data-close]',
    '.close',
  ].join(', ');

  const closeButton =
    shadowRoot.querySelector(
      closeSelector
    );

  if (!closeButton) {
    console.warn(
      '[Elite] Кнопка закрытия popup не найдена'
    );

    return;
  }

  closeButton.addEventListener(
    'click',
    () => {
      sendCapsulaClickMetric('close');
    }
  );
}

export function observeHeaderMarkup() {
  return reactDomObserver()
    .observeSelector$(
      HEADER_SELECTOR,
      {
        emitRemove: false,
      }
    )
    .subscribe(({element: header}) => {
      if (
        document.querySelector(
          POPUP_TRIGGER_SELECTOR
        )
      ) {
        return;
      }

      header.insertAdjacentHTML(
        'afterend',
        markup
      );
    });
}

export async function mountPopup() {
  await customElements.whenDefined(
    'coral-popup'
  );

  let popup =
    document.querySelector(
      POPUP_SELECTOR
    );

  if (!popup) {
    document.body.insertAdjacentHTML(
      'beforeend',
      popupMarkup
    );

    popup =
      document.querySelector(
        POPUP_SELECTOR
      );
  }

  bindShadowCloseMetric(popup);

  return popup;
}

export function bindPopupInteractions() {
  document.addEventListener(
    'click',
    (event) => {
      if (
        !(event.target instanceof Element)
      ) {
        return;
      }

      const popup =
        document.querySelector(
          POPUP_SELECTOR
        );

      const learnMoreLink =
        event.target.closest(
          `${POPUP_SELECTOR} .learn-more`
        );

      if (learnMoreLink) {
        sendLearnMoreMetric();
      }

      const popupTrigger =
        event.target.closest(
          POPUP_TRIGGER_SELECTOR
        );

      if (popupTrigger) {
        sendPopupOpenMetric();

        popup?.show();

        return;
      }

      const noThanksButton =
        event.target.closest(
          `${POPUP_SELECTOR} .close-btn`
        );

      if (noThanksButton) {
        const currentPopup =
          noThanksButton.closest(
            POPUP_SELECTOR
          );

        sendCapsulaClickMetric(
          'no_thanks'
        );

        currentPopup?.hide();
      }
    }
  );
}
