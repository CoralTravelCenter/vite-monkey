import {PERSONALIZED_CONTENT_SELECTOR,} from './constants.js';

function createContentElement(
  tagName,
  text
) {
  const element =
    document.createElement(tagName);

  element.textContent = text;

  return element;
}

export function renderContent(content) {
  const contentElements =
    document.querySelectorAll(
      PERSONALIZED_CONTENT_SELECTOR
    );

  contentElements.forEach((element) => {
    const hasClientName = Boolean(
      content.clientName
    );

    const description =
      `${hasClientName ? 'с' : 'С'}оберите идеальное путешествие\n` +
      'под ваш неповторимый стиль.';

    const contentNodes = [
      createContentElement(
        'p',
        description
      ),
    ];

    if (hasClientName) {
      contentNodes.unshift(
        createContentElement(
          'h3',
          `${content.clientName},`
        )
      );
    }

    element.replaceChildren(
      ...contentNodes
    );
  });
}
