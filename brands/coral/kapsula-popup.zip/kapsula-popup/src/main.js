import './style.scss';

import {createContent$} from './scripts/authorization.js';
import {renderContent} from './scripts/content.js';

import {bindPopupInteractions, mountPopup, observeHeaderMarkup,} from './scripts/popup.js';

async function init() {
  let content = {
    authorized: false,
    clientName: '',
  };

  createContent$().subscribe({
    next(nextContent) {
      content = nextContent;

      renderContent(content);
    },

    error(error) {
      console.error(
        '[Elite] Ошибка отслеживания авторизации:',
        error
      );
    },
  });

  observeHeaderMarkup();

  bindPopupInteractions();

  await mountPopup();

  renderContent(content);
}

init().catch((error) => {
  console.error(
    '[Elite] Не удалось инициализировать popup:',
    error
  );
});
